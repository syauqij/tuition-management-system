<div class="alert alert-{{ $type }} text-base text-red-700 mt-1">
  {{ $message }}
</div>