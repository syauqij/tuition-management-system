<h2 class="text-gray-500 font-normalt">
  {{ $label }}
</h2>
<p class="text-gray-900 font-semibold">
  {{ $value ?? $slot}}
</p>
