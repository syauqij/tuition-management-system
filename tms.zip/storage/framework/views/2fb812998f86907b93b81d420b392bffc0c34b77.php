<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['options', 'title' => '', 'selected' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['options', 'title' => '', 'selected' => '']); ?>
<?php foreach (array_filter((['options', 'title' => '', 'selected' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<select <?php echo e($attributes
  ->class([
    '',
    'border-red-500' => $errors->has($attributes->get('name'))])
  ->merge(['disabled' => false])); ?>>

  <option value=""> Choose the <?php echo e($title); ?> </option>

  <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemName => $itemId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($selected): ?>
      <option value="<?php echo e($itemId); ?>"
        <?php if(in_array($itemId, $selected)): ?>
          selected
        <?php endif; ?>>
          <?php echo e($itemName); ?>

      </option>
    <?php else: ?>
      <option value="<?php echo e($itemId); ?>"> <?php echo e($itemName); ?> </option>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/components/forms/choices.blade.php ENDPATH**/ ?>