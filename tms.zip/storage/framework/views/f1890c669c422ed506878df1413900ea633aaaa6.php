<div class="lg:w-2/6 md:w-1/2 bg-gray-100 rounded-lg p-8 flex flex-col md:ml-auto w-full mt-10 md:mt-0">
  <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\tuition-management-system\resources\views/components/content/auth-card.blade.php ENDPATH**/ ?>