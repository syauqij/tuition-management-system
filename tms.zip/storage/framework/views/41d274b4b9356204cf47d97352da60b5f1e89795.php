<div class="md:w-8/12 lg:w-6/12 mb-12 md:mb-0">
    <h1 class="title-font font-medium text-3xl text-gray-900">
      <?php echo e($title); ?>

    </h1>

    <p class="leading-relaxed mt-4">
      <?php echo e($slot); ?>

    </p>
</div><?php /**PATH C:\xampp\htdocs\tuition-management-system\resources\views/components/content/column-text.blade.php ENDPATH**/ ?>