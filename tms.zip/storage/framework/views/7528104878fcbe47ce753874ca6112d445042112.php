<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['selected' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['selected' => '']); ?>
<?php foreach (array_filter((['selected' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<input <?php echo e($attributes
  ->class(['w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500'
    => $errors->has($attributes->get('name'))
  ])->merge(['disabled' => false])); ?> <?php if($attributes->get('value') == $selected): echo 'checked'; endif; ?> />
<?php /**PATH C:\xampp\htdocs\tms\resources\views/components/forms/radio-input.blade.php ENDPATH**/ ?>