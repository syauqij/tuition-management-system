<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <?php echo e(__('Courses')); ?>

      </h2>
   <?php $__env->endSlot(); ?>

  <div class="container px-5 py-20 mx-auto">

    <div class="flex flex-wrap w-full mb-10 flex-col items-center text-center">
      <h1 class="text-5xl xl:text-6xl font-bold tracking-tight mb-12">Explore Our Courses</h1>
      <p class="text-2xl font-medium mb-4">We offer
        <span class="text-indigo-600">quality and certified</span> courses</p>
      <p class="lg:w-4/5 w-full leading-relaxed text-gray-500 text-xl">
        Enrol our Award Winning courses to Jump Start your child’s Learning Journey.
      </p>
    </div>

    <form method="get" action="<?php echo e(route('courses.search')); ?>">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.search-input','data' => ['name' => 'keywords','value' => ''.e($keywords ?? null).'','placeholder' => 'Enter course name, subject or subject category']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'keywords','value' => ''.e($keywords ?? null).'','placeholder' => 'Enter course name, subject or subject category']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="grid grid-flow-row auto-rows-max md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-6 text-center justify-center">
        <?php if($courses->isEmpty()): ?>
          <div class="col-span-3">
            <h1 class="text-lg text-red-500 font-bold mt-5"> No courses found. Please improve your search keywords. <h1>
          </div>
        <?php endif; ?>

        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p-6 border-2 border-gray-600 bg-white max-w-sm
            hover:border-indigo-600 hover:border-4 hover:border-spacing-10
            hover:shadow-lg hover:shadow-indigo-500/50
            ease-in-out cursor-pointer">
            <a href="<?php echo e(route('courses.show', [
              'id' => $course->id,
              'slug' => $course->slug,
              ])); ?>">
            <h5 class="text-gray-900 text-xl leading-tight font-semibold mb-2 hover:text-indigo-800 hover:underline decoration-double">
              <?php echo e($course->name); ?>

            </h5>
            <object class="text-gray-700 text-base mb-1 font-mono hover:text-indigo-700 hover:underline decoration-solid">
              <a href="<?php echo e(route('courses.filter', [
                  'id' => $course->subjectCategory->id,
                  'type' => 'subjectCategory',
                  'name' => $course->subjectCategory->name
                ])); ?>">
                  <?php echo e($course->subjectCategory->name); ?>

              </a>
            </object>
            <object class="text-gray-700 text-base mb-4 font-light hover:text-indigo-700 hover:underline decoration-dotted">
              <a href="<?php echo e(route('courses.filter', [
                  'id' => $course->subject->id,
                  'type' => 'subject',
                  'name' => $course->subject->name
                ])); ?>">
                  <?php echo e($course->subject->name); ?>

              </a>
            </object>
            <img src="https://mdbootstrap.com/img/new/standard/city/041.jpg"
              class="mb-4"
              alt="..."/>
          </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="py-4 pr-4">
      <?php echo e($courses->links()); ?>

    </div>
  </form>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/courses.blade.php ENDPATH**/ ?>