<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['colours' => 'text-gray-500 bg-gray-200 active:bg-gray-300']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['colours' => 'text-gray-500 bg-gray-200 active:bg-gray-300']); ?>
<?php foreach (array_filter((['colours' => 'text-gray-500 bg-gray-200 active:bg-gray-300']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<span class="px-4 py-2 rounded-full <?php echo e($colours); ?>

    font-semibold text-sm flex align-center w-max cursor-pointer
    transition duration-300 ease">
  <?php echo e($slot); ?>

</span>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/components/content/tag.blade.php ENDPATH**/ ?>