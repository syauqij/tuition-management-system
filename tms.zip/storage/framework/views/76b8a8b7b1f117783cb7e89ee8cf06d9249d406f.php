<?php if($message): ?>
  <div <?php echo e($attributes); ?>>
    <div class="bg-green-100 rounded-lg shadow-sm py-5 px-6 text-base text-green-700" role="alert">
      <?php echo e($message); ?>

    </div>
  </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/components/alerts/success.blade.php ENDPATH**/ ?>