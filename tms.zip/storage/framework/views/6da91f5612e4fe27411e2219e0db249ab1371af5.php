<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['width' => 'sm:w-1/2', 'align' => 'p-4 justify-left']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['width' => 'sm:w-1/2', 'align' => 'p-4 justify-left']); ?>
<?php foreach (array_filter((['width' => 'sm:w-1/2', 'align' => 'p-4 justify-left']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="p-2 w-full <?php echo e($width); ?>">
  <div class="bg-gray-100 rounded flex h-full items-center <?php echo e($align); ?>">
    <?php if(isset($icon)): ?>
      <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" 
        class="text-indigo-500 w-6 h-6 flex-shrink-0 mr-4" viewBox="0 0 24 24">
        <?php echo e($icon); ?>

      </svg>
    <?php endif; ?>
    <span class="title-font font-medium tracking-widest truncate block">
      <?php echo e($slot); ?>

    </span>
  </div>
</div><?php /**PATH C:\xampp\htdocs\tms\resources\views/components/content/setting-card.blade.php ENDPATH**/ ?>