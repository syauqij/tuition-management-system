<div class="px-5 py-20 mx-auto bg-gray-100">
  <div class="lg:w-4/6 flex flex-col sm:flex-row sm:items-center items-start mx-auto">
    <h1 class="flex-grow sm:pr-16 text-2xl font-medium title-font text-indigo-600">
      Join TMS Now <br/>
      <span class="text-xl text-black">
        Don’t get left behind. More than 59,000 students are learning
        <br class="hidden lg:inline-block">something new with TMS every day.
      </span>
    </h1>
    <a href=" <?php echo e(route('register')); ?> " >
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.button-primary','data' => ['class' => 'text-lg py-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.button-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-lg py-4']); ?>
        <?php echo e(__('REGISTER NOW')); ?>

       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </a>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/layouts/register-now.blade.php ENDPATH**/ ?>