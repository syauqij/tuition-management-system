  <form method="get" action="<?php echo e(route('courses.search')); ?>">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.search-input','data' => ['name' => 'keywords','value' => ''.e($keywords ?? null).'','placeholder' => 'Enter course name, subject or subject category']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'keywords','value' => ''.e($keywords ?? null).'','placeholder' => 'Enter course name, subject or subject category']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="grid grid-flow-row auto-rows-max md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-6 text-center justify-center">
        <?php if($courses->isEmpty()): ?>
          <div class="col-span-3">
            <h1 class="text-lg text-red-500 font-bold mt-5">
              No courses found. Please improve your search keywords.
            </h1>
          </div>
        <?php endif; ?>

        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p-6 border-2 border-gray-600 bg-white max-w-sm
            hover:border-indigo-600 hover:border-4 hover:border-spacing-10
            hover:shadow-lg hover:shadow-indigo-500/50
            ease-in-out cursor-pointer">
            <?php if(isset($enrol)): ?>
              <a href="<?php echo e(route('enrolments.create', [
                'course_id' => $course->id,
                'slug' => $course->slug,
                ])); ?>">
            <?php else: ?>
              <a href="<?php echo e(route('courses.show', [
                'id' => $course->id,
                'slug' => $course->slug,
                ])); ?>">
            <?php endif; ?>

            <h5 class="text-gray-900 text-xl leading-tight font-semibold mb-2
              hover:text-indigo-800 hover:underline decoration-double truncate">
              <?php echo e($course->name); ?>

            </h5>
            <object class="text-gray-700 text-base mb-1 font-mono truncate
              hover:text-indigo-700 hover:underline decoration-solid">
              <a href="<?php echo e(route('courses.filter', [
                  'id' => $course->subjectCategory->id,
                  'type' => 'subjectCategory',
                  'name' => $course->subjectCategory->name
                ])); ?>">
                  <?php echo e($course->subjectCategory->name); ?>

              </a>
            </object>
            <img src="<?php echo e(asset('storage/' . $course->main_photo_path)); ?>" class="my-2"
              alt="course-main-photo" title="<?php echo e($course->main_photo_path); ?>" >
          </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="py-4">
      <?php echo e($courses->links()); ?>

    </div>

  </form>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/courses/list.blade.php ENDPATH**/ ?>