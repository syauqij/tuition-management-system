<input <?php echo e($attributes
  ->class(['w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500' 
    => $errors->has($attributes->get('name'))
  ])->merge(['disabled' => false])); ?> <?php if(old($attributes->get('name')) == $attributes->get('value')): echo 'checked'; endif; ?> /><?php /**PATH C:\xampp\htdocs\tuition-management-system\resources\views/components/forms/radio-input.blade.php ENDPATH**/ ?>