<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['width' => 'xl:w-6/12']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['width' => 'xl:w-6/12']); ?>
<?php foreach (array_filter((['width' => 'xl:w-6/12']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="flex justify-center">
  <div class="mb-10 mr-4 <?php echo e($width); ?>">
    <div class="input-group relative flex flex-wrap items-stretch w-full">
      <input type="search" <?php echo e($attributes); ?>

        class="form-control relative flex-auto block w-full px-3 py-1.5 border-2 font-normal text-blue-700
            focus:border-indigo-800 focus:bg-gray-100 rounded transition ease-in-out m-0">

      <button type="submit" id="button-search"
        class="btn inline-block px-6 py-2 border-2 border-gray-600 text-gray-600 font-semibold
          leading-tight uppercase rounded hover:bg-indigo-600 hover:text-white
          focus:outline-none focus:ring-0 transition duration-150 ease-in-out">
            Search
      </button>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/components/forms/search-input.blade.php ENDPATH**/ ?>