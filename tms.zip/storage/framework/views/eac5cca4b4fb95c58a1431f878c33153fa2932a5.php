<div class="alert alert-<?php echo e($type); ?> text-base text-red-700 mt-1">
  <?php echo e($message); ?>

</div><?php /**PATH C:\xampp\htdocs\tms\resources\views/components/alerts/message.blade.php ENDPATH**/ ?>