<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 
  'text-gray-700 bg-gray-100 border-0 py-2 px-6 focus:outline-none hover:bg-gray-200 rounded text-lg'
])); ?>>
  <?php echo e($slot); ?>

</button><?php /**PATH C:\xampp\htdocs\tuition-management-system\resources\views/components/forms/button-secondary.blade.php ENDPATH**/ ?>