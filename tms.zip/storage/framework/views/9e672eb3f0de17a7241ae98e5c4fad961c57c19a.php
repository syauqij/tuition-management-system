<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name' => 'Action', 'id' => 'dropdownMenu', 'colour' => 'bg-gray-700']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name' => 'Action', 'id' => 'dropdownMenu', 'colour' => 'bg-gray-700']); ?>
<?php foreach (array_filter((['name' => 'Action', 'id' => 'dropdownMenu', 'colour' => 'bg-gray-700']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
if ($name == "accepted") {
  $colour = 'bg-green-700';
}

if ($name == "rejected") {
  $colour = 'bg-red-700';
}
?>

<div class="dropdown relative inline-block">
  <a class="dropdown-toggle px-6 py-2.5 <?php echo e($colour); ?> text-white font-medium text-xs leading-tight uppercase rounded
      shadow-md hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0 active:shadow-lg active:text-white
      transition duration-150 ease-in-out flex items-center whitespace-nowrap w-full"
    href="#"
    type="button" id="<?php echo e($id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
      <?php echo e($name); ?>

    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="caret-down" class="w-2 ml-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
      <path fill="currentColor"
        d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z">
      </path>
    </svg>
  </a>
  <ul class="dropdown-menu min-w-max absolute hidden bg-white text-base z-50 float-left py-2
      list-none text-left rounded-lg shadow-lg mt-1 m-0 bg-clip-padding border-none bg-red"
    aria-labelledby="<?php echo e($id); ?>">
      <?php echo e($menu); ?>

  </ul>
</div>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/components/forms/button-dropdown.blade.php ENDPATH**/ ?>