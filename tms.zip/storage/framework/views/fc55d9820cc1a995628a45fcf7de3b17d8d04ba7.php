<h2 class="text-gray-500 font-normalt">
  <?php echo e($label); ?>

</h2>
<p class="text-gray-900 font-semibold">
  <?php echo e($value ?? $slot); ?>

</p>
<?php /**PATH C:\xampp\htdocs\tms\resources\views/components/content/profile-detail.blade.php ENDPATH**/ ?>